import { api } from './api.js';//para traer el manejo de la api

export const auth = {
  // Implementa la función de login
    login: async (email, pass) => {
        // Confirma en la api la información del usuario, en este caso, Correo y contraseña
    const users = await api.get(`/users?email=${email}`);
    if (users.length === 0 || users[0].password !== pass) {
        throw new Error('ups... datos ingresados erroneamente');
    }
    const user = users[0];
    localStorage.setItem('user', JSON.stringify(user)); // Guarda el usuario en localStorage
    },
  // Implementa la función de registro
    register: async (name, email, pass) => {
        //Evita que se duplique el correo, de existir lanza un mensaje
        // de otro modo guarda la información en localStorage
    const existingUser = await api.get(`/users?email=${email}`);
    if (existingUser.length > 0) {
        throw new Error('El email ya está registrado');
    }
    const newUser = { name, email, password: pass, role: 'user' };
    await api.post('/users', newUser); // Registra el nuevo usuario
    },
  // Implementa la función de logout
    logout: () => {
    // TODO: Elimina el usuario de localStorage y redirige a login
    localStorage.removeItem('user');
    location.reload();
    },

    isAuthenticated: () => {
    
    return !!localStorage.getItem('user'); 
    },
  // Devuelve el usuario autenticado
    getUser: () => {
    // TODO: Devuelve el usuario guardado en localStorage (o null)
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null; // Devuelve el usuario parseado o null si no existe
    
}
};