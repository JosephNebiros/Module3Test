// Importa los módulos necesarios
import { auth } from './auth.js';
import {
  showLogin, // Implementa en views.js
  showRegister, // Implementa en views.js
  showDashboard, // Implementa en views.js
  showEvents, // Implementa en views.js
  showCreateEvent, // Implementa en views.js
  showEditEvent, // Implementa en views.js
  renderNotFound // Implementa en views.js
} from './views.js';

// Define aquí las rutas de tu SPA
const routes = {
  '#/login': showLogin, // Vista de login
  '#/register': showRegister, // Vista de registro
  '#/dashboard': showDashboard, // Vista principal tras login
  '#/dashboard/events': showEvents, // Listado de eventos
  '#/dashboard/events/create': showCreateEvent, // Formulario para crear evento
  '#/dashboard/events/edit/' : showEditEvent
  // Puedes agregar más rutas según lo necesites
};

// Función principal de enrutamiento
export function router() {
  const path = location.hash || '#/login';
  const user = auth.getUser();

  // Ejemplo: proteger rutas de dashboard
  if (path.startsWith('#/dashboard') && !auth.isAuthenticated()) {
    location.hash = '#/login';
    return;
  }

  // Ejemplo: evitar que usuarios logueados accedan a login/register
  if ((path === '#/login' || path === '#/register') && auth.isAuthenticated()) {
    location.hash = '#/dashboard';
    return;
  }

  // Ejemplo: ruta dinámica para editar evento
  if (path.startsWith('#/dashboard/events/edit/')) {
    showEditEvent(); // Implementa esta función en views.js
    return;
  }

  // Cargar la vista correspondiente
  const view = routes[path];
  if (view) {
    view();
  } else {
    renderNotFound(); // Implementa esta función en views.js
  }
}