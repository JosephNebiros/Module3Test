import { api } from './api.js'; // Implementa y exporta funciones de API en api.js
import { auth } from './auth.js'; // Implementa y exporta funciones de autenticación en auth.js
import { router } from './router.js'; // Importa el enrutador para redirigir después de acciones

// Muestra un mensaje de página no encontrada
export function renderNotFound() {
document.getElementById('app').innerHTML = `
    <section>
        <h2>Página no encontrada</h2>
        <a href="/" data-link>Volver al inicio</a>
    </section>
    `;
}

// Implementa la vista de login
export async function showLogin() {
  document.getElementById('app').innerHTML = `
    <div class="login-container">
      <form id="form" class="login-form card">
        <h2 style="text-align:center; margin-bottom:1em;">Login</h2>
        <input type="email" id="e" placeholder="email">
        <input type="password" id="p" placeholder="pass">
        <button>Entrar</button>
        <br>
        <a href="#/register" data-link>¿No tienes cuenta? Regístrate</a>
      </form>
    </div>`;
  document.getElementById('form').onsubmit = async e => {
    e.preventDefault();
    try {
      await auth.login(e.target.e.value, e.target.p.value);
      location.hash = '#/dashboard';
      router();
    } catch (err) {
      alert(err.message);
    }
  };
}

// Implementa la vista de registro
export async function showRegister() {
  document.getElementById('app').innerHTML = `
    <div class="login-container">
      <form id="f" class="login-form card">
        <h2 style="text-align:center; margin-bottom:1em;">Registro</h2>
        <input placeholder="nombre" id="n">
        <input placeholder="email" id="e">
        <input placeholder="pass" id="p">
        <button>Registrar</button>
      </form>
    </div>`;
  document.getElementById('f').onsubmit = async e => {
    e.preventDefault();
    try {
      await auth.register(e.target.n.value, e.target.e.value, e.target.p.value);
      location.hash = '#/dashboard';
      router();
    } catch (err) {
      alert(err.message);
    }
  };
}

// Implementa la vista principal del dashboard
export async function showDashboard() {
  const u = auth.getUser();
  document.getElementById('app').innerHTML = `
    <h2>Bienvenido, ${u.name} (${u.role})</h2>
    <button id="out" >Salir</button>
    <p>Esta es una página de registro de eventos, en ella podrás encontrar la lista de eventos disponibles, incluidos sus cupos. podrás inscribirte a los eventos que aún tengan cupos, disfruta!</p>
    <nav>
      <a href="#/dashboard/events" data-link>Ver eventos</a>
      ${u.role === 'admin' ? `<a href="#/dashboard/events/create" data-link>Crear evento</a>` : ''}
    </nav>`;  
  document.getElementById('out').onclick = auth.logout;
  document.querySelectorAll('[data-link]').forEach(a => {
    a.onclick = e => {
      e.preventDefault();
      location.hash = a.getAttribute('href');
    };
  });
}

// Implementa la vista de listado de cursos
export async function showEvents() {
  const user = auth.getUser();
  const events = await api.get('/events');

  document.getElementById('app').innerHTML = `
    <h2>Eventos disponibles</h2>
    <ul>${events.map(e => `
      <li>${e.title || 'Sin título'} (${e.capacity || 0} cupos) — Organizador: ${e.organizer || 'N/A'}
        ${user.role === 'admin' ? `<button onclick="showEditEvent(${e.id})">Editar</button>` : ''}
        ${user.role === 'admin' ? `<button onclick="deleteEvent(${e.id}) class=delete-btn">Eliminar</button>` : ''}
        ${user.role === 'user' ? `<button class="attend-btn" data-id="${e.id}">Asistir</button>` : ''}
      </li>`).join('')}</ul>
      <a href="/" data-link>Volver al inicio</a>`;

  if (user.role === 'user') {
    document.querySelectorAll('.attend-btn').forEach(btn => {
      btn.onclick = async () => {
        const eventId = btn.dataset.id;

        // Obtener curso actual
        const event = await api.get('/events/' + eventId);

        // Simular lista de inscritos (opcional)
        if (!event.attendees) event.attendees = [];

        // Evitar doble inscripción
        if (event.attendees.includes(user.email)) {
          alert('Ya estás inscrito en este evento.');
          return;
        }

        let capacity=event.capacity-1;

        // Verificar capacidad
        if (event.attendees.length >= event.capacity) {
          alert('Este evento ya está lleno.');
          return;
        }

        event.attendees.push(user.email);
        event.capacity = capacity;

        await api.put('/events/' + eventId, event);
        alert('Registro exitoso!');
        showEvents(); // recargar lista
      };
    });
  }
}

// Implementa la vista para crear un curso (solo admin)
export function showCreateEvent() {
  document.getElementById('app').innerHTML = `
    <h2>Crear Evento</h2>
    <form id="f">
      <input placeholder="Título" id="title">
      <input placeholder="Organizador" id="organizer">
      <input type="number" placeholder="Capacidad" id="capacity">
      <button>Guardar</button>
    </form>
    <a href="/" data-link>Volver al inicio</a>`;
    
  document.getElementById('f').onsubmit = async e => {
    e.preventDefault();
    const data = {
      id: e.target.id.value,
      title: e.target.title.value,
      organizer: e.target.organizer.value,
      capacity: parseInt(e.target.capacity.value)
    };
    await api.post('/events', data);
    location.hash = '#/dashboard/events';
    router();
  };
}

// Implementa la vista para editar un curso (solo admin)
export async function showEditEvent() {
  const user = auth.getUser();
  if (user.role !== 'admin') {
    renderNotFound();
    return;
  };

  const eventId = location.hash.split('/').pop();
  const event = await api.get('/events/' + eventId);

  if (!event) {
    renderNotFound();
    return;
  };

  document.getElementById('app').innerHTML = `
    <h2>Editar Evento</h2>
    <form id="f">
      <input id="title" placeholder="Título" value="${event.title}">
      <input id="organizer" placeholder="Organizador" value="${event.organizer}">
      <input type="number" id="capacity" placeholder="Capacidad" value="${event.capacity}">
      <button>Guardar</button>
    </form>`;

  document.getElementById('f').onsubmit = async e => {
    e.preventDefault();
    const updated = {
      title: e.target.title.value,
      organizer: e.target.organizer.value,
      capacity: parseInt(e.target.capacity.value)
    };
    await api.put('/events/' + eventId, updated);
    location.hash = '#/dashboard/events';
    router();
  };
}
export async function deleteEvent() {
window.deleteEvent = async (id) => {
  const confirmar = confirm('¿Estás seguro de que deseas eliminar este evento?');
  if (!confirmar) return;

  try {
    await api.del(`/events/${id}`);
    alert('Evento eliminado correctamente');
    showEvents(); // recargar lista
  } catch (error) {
    alert('Ocurrió un error al eliminar el evento.');
    console.error(error);
  }}};
window.showEditEvent = (id) => {
  location.hash = `#/dashboard/events/edit/${id}`;
};